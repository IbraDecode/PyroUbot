__MODULE__ = "ɢʀᴏᴜᴘ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Group

perintah : <code>{0}etmin</code>
    Untuk Mengadminkan

perintah : <code>{0}demote</code>
    Untuk Mengunadmin

perintah : <code>{0}ceo</code>
    Untuk Mengownerkan Orang

perintah : <code>{0}getlink</code>
    Untuk Mengambil Link Group</blockquote></b>
"""